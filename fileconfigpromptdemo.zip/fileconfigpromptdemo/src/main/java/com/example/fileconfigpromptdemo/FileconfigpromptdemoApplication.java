package com.example.fileconfigpromptdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileconfigpromptdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileconfigpromptdemoApplication.class, args);
	}

}
